<footer>
	<div class="row">
		<div class="col-md-8">
			<marquee class="footer" onmouseover="stop();" onmouseout="start()">
		Ayolahhhhh
			</marquee>
		</div>
		<div class="col-md-4">
	
	<a class="footer" href="login">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ? '</strong>' : '' ?></a>
	<a class="footer" href="antrian">Nomer Antrian</a>

		</div>
	</div>
</footer>

<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>

</body>
</html>