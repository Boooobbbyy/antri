
<section>
	<div class="container">

	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<div class="box">
				<div class="loket">
					Nomer Antrian Anda
				</div>
				<div class="agenda">
					<h1 id="nomer">
					</h1>
							<a href="<?php echo site_url('welcome/tambah_antrian/') ?>" class="btn btn-primary"><i class="fas fa-download"></i> &nbsp;Dapatkan Nomer Antrian</a>
					<br>
				</div>
			</div>
		</div>
	</div>

    </div>
</section>