<?php $this->load->view('admin/head'); ?>

<?php $this->load->view('admin/navbar'); ?>

<?php $this->load->view('admin/konten/' . $tampilan); ?>

<?php $this->load->view('admin/footer'); ?>
