<?php $this->load->view('layout'); ?>

<?php $this->load->view('/' . $tampilan); ?>

<?php $this->load->view('foot'); ?>
