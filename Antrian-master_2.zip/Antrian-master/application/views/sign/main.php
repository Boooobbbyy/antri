<?php $this->load->view('sign/auth_header'); ?>

<?php $this->load->view('sign/' . $tampilan); ?>

<?php $this->load->view('sign/auth_footer'); ?>
